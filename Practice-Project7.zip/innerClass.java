package demo;

public class innerClass {
	 class Inner
	    {
	        public void show ()
	        {
	            System.out.println ("This is Inner Class");
	        }
	    }
	    
	    public static void main (String[]args)
	    {
	        innerClass.Inner in = new innerClass ().new Inner ();
	        in.show ();
	    }
}
