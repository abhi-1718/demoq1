package demo;

public class arrayImpli {

		public static void main(String[] args) {

		//1D array
		int a[]= {1,2,3,4,5};
		for(int i=0;i<5;i++) {
		System.out.println("Elements of array a: "+a[i]);
		}


		//multidimension array
		int[][] b = {{10, 70, 90, 25},{39, 61, 94}};
		      
		      System.out.println("\nLength of row 1: " + b[0].length);
		      System.out.println("Length of row 2: " + b[1].length);
		      }
		}
