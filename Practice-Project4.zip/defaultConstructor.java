package demo;
class Test{
	int a;
	boolean b;
}

public class defaultConstructor {
	public static void main(String[] args) {

	    // calling a default constructor
	    Test obj = new Test();

	    System.out.println("Default Value:");
	    System.out.println("a = " + obj.a);
	    System.out.println("b = " + obj.b);
	  }
	}

