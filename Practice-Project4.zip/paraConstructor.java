package demo;
class main{
	static int id;
	static String name;
	main(int x, String y){
		id = x;
		name = y;
	}
	    static void show() {
		System.out.println(id+ " " + name);
		
	}
}
public class paraConstructor {
	public static void main(String[] args) {
		main main1 = new main(17,"Abhisek");
		main.show();
	}

}
