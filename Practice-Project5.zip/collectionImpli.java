package demo;

import java.util.*;

public class collectionImpli {
	public static void main(String[] args) {

		// Arraylist
		System.out.println("ArrayList: ");
		ArrayList<String> avengers = new ArrayList<String>();
		avengers.add("Captain America");//
		avengers.add("Tony Stark");
		avengers.add("Thor");
		avengers.add("Hulk");
		System.out.println(avengers);
		System.out.println("\n");

		// Hashset
		System.out.println("HashSet: ");
		HashSet<String> number= new HashSet<String>();
		number.add("First");
		number.add("Second");
		number.add("Thired");
		number.add("Fourth");
		System.out.println(number);
		System.out.println("\n");

		// Linkedlist
		System.out.println("LinkedList: ");
		LinkedList<String> villians = new LinkedList<String>();
		villians.add("Galactus");
		villians.add("Thanos");
		villians.add("Kang");
		villians.add("Dr Doom");
		Iterator<String> itr = villians.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
	}
}