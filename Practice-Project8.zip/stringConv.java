package demo;

public class stringConv {
	    public static void main(String[] args) {
	        // Creating a String
	        String str= "Good Morning";

	        // Converting String to StringBuffer
	        StringBuffer strBuf = new StringBuffer(str);
	        // Converting String to StringBuilder
	        StringBuilder strBuild = new StringBuilder(str);

	        // Displaying the original String
	        System.out.println("Original String: " + str);

	        // Displaying the StringBuffer
	        System.out.println("StringBuffer: " + strBuf);

	        // Displaying the StringBuilder
	        System.out.println("StringBuilder: " + strBuild);
	    }
	}

